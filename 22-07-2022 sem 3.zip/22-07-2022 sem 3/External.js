  var a=143;
var b=143;
var c=a+b;

document.write("Sum Value:- ",c);